package Lab;

public interface ItemTwo {
  /*
   * Name: Keldin Maldonado
   * Date: 2022 - 11 - 13
   * Description: Part of the lab on one of the pillars
   * of OOP: inheritance.
   * Lab done with Dr. C's video walk through--practicing inheritance.
   */

  void deactivate();
}
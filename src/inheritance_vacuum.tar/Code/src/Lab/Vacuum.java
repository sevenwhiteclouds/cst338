package Lab;

public abstract class Vacuum implements ItemOne, ItemTwo{
  /*
   * Name: Keldin Maldonado
   * Date: 2022 - 11 - 13
   * Description: Part of the lab on one of the pillars
   * of OOP: inheritance.
   * Lab done with Dr. C's video walk through--practicing inheritance.
   */

  Boolean on;

  Vacuum(){
    on = false;
  }

  public Boolean isOn() {
    return on;
  }

  @Override
  public void deactivate() {
    if (on) {
      System.out.println("Turning " + this + " off");
      on = false;
    } else {
      System.out.println(this + " is already off");
    }
  }

  @Override
  public void activate() {
    if (on) {
      System.out.println(this + " is already on");
    } else {
      System.out.println("Turning " + this + "on");
      on = true;
    }
  }
}
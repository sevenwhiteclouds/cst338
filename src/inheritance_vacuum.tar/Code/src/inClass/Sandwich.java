package inClass;

import java.util.HashMap;

public interface Sandwich {
      public String listFilling();
}
